<h1 align="center">🌀 Discord Nitro Generator V2 🌀</h1>
<h3 align="center">Generates Classic and Boost Nitro codes and checks them</h3>
<h4 align="center">⭐ Don't forget to leave a star! ⭐</h4>

## Requirements:
* Python 3 (tested on 3.7 and 3.8)
* Everything in `requirements.txt`

## Usage:
1. Install requirements (`py -3 -m pip install -r requirements.txt`)
2. Launch `main.py`

## Showcase:
![Showcase](https://i.imgur.com/9hYb7Sp.png)
